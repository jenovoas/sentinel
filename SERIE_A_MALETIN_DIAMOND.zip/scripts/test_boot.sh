#!/bin/bash
# scripts/test_boot.sh
# Testing Sentinel Init System in QEMU

set -e

PROJECT_ROOT=$(pwd)
INITRD="$PROJECT_ROOT/initramfs.cpio.gz"
KERNEL="/boot/vmlinuz-$(uname -r)"

if [ ! -f "$INITRD" ]; then
    echo "Error: $INITRD not found. Run scripts/build_initramfs.sh first."
    exit 1
fi

if [ ! -f "$KERNEL" ]; then
    # Try common alternatives if the specific version isn't at the root of /boot
    KERNEL=$(ls /boot/vmlinuz-* | head -n 1)
fi

echo "[sentinel-test] Launching Sentinel OS Foundation Core in QEMU..."
echo "[sentinel-test] Kernel: $KERNEL"

# Clean up stale socket to prevent QEMU bind error
rm -f /tmp/sentinel_cortex.sock

qemu-system-x86_64 \
    -kernel "$KERNEL" \
    -initrd "$INITRD" \
    -append "console=ttyS0 quiet panic=1 init=/init sysctl.kernel.perf_event_paranoid=-1" \
    -chardev socket,path=/tmp/sentinel_cortex.sock,server=on,wait=off,id=cortex_channel \
    -serial mon:stdio \
    -serial chardev:cortex_channel \
    -nographic \
    -m 512M \
    -no-reboot
